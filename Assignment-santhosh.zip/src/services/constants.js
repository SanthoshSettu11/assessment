export const NOODLELIST = "TopRamen8d30951.json";
export const NOODLEIMAGE = "noodlesec253ad.json";