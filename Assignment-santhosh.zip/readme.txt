#instructions

1. run command line 'npm install' in root folder.

2. run 'npm start'

3. applications will run and you can access it in 'http://localhost:3000'


