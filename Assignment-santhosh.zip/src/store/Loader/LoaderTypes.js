export const START_LOADER = "START_LOADER";
export const STOP_LOADER = "STOP_LOADER";