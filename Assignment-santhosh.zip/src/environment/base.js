export const environment_URL = {
    baseURL: "https://s3-ap-southeast-1.amazonaws.com/he-public-data/"
  };